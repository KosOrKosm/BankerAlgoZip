package banking;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class Customer {

	private static class ResourceRequirement {
		private final int need;
		private int has;

		private ResourceRequirement(int need, int has) {
			this.need = need;
			this.has = has;
		}

		public boolean unsatisfied() {
			return need != has;
		}

		public int remainingNeed() {
			return need - has;
		}

		public int has() {
			return has;
		}

		public void receive(int amount) {
			has += amount;
			if (has > need)
				throw new IllegalStateException("Customer provided more resources than needed!");
		}
	}

	private final List<ResourceRequirement> requirements = new ArrayList<>();

	public Customer(List<Integer> req, List<Integer> preallocated) {
		if (preallocated.size() != req.size())
			throw new IllegalArgumentException("List sizes must match!");
		for (int i = 0; i < req.size(); i++)
			requirements.add(new ResourceRequirement(req.get(i), preallocated.get(i)));
	}

	public boolean satisfied() {
		for (ResourceRequirement req : requirements)
			if (req.unsatisfied())
				return false;
		return true;
	}

	public boolean complete() {
		return requirements.size() < 1;
	}

	public boolean canFullyAllocate(Banker bank) {
		for (int i = 0; i < requirements.size(); ++i) {
			ResourceRequirement req = requirements.get(i);
			if (req.unsatisfied() && bank.cannotCompleteRequest(i, req.remainingNeed()))
				return false;
		}
		return true;
	}

	public void allocateAllResources(Banker bank) {
		for (int i = 0; i < requirements.size(); ++i) {
			ResourceRequirement req = requirements.get(i);
			bank.allocateResource(i, req.remainingNeed());
			req.receive(req.remainingNeed());
		}
	}

	public void returnAllResources(Banker bank) {

		if (!satisfied())
			throw new IllegalStateException("Attempt to deallocate a Customer before it's task was completed!");

		for (int i = 0; i < requirements.size(); ++i) {
			ResourceRequirement req = requirements.get(i);
			bank.deallocateResource(i, req.has());
		}
		requirements.clear();

	}

	public List<Integer> needs() {
		List<Integer> ret = new ArrayList<>();
		for (ResourceRequirement req : requirements) {
			ret.add(req.remainingNeed());
		}
		return ret;
	}
	
	private static String padNum(int length, int num) {
		int num_tmp = num;
		while((num_tmp = num_tmp / 10) > 0)
			length--;
		String ret = Integer.toString(num);
		if(length < 1)
			return ret;
		char[] padding = new char[length];
		Arrays.fill(padding, ' ');
		return new String(padding) + ret;
	}
	
	public String allocatedResourcesAsString(int numMaxSize) {
		StringBuilder ret = new StringBuilder("[");
		for(int i = 0; i < requirements.size(); ++i) { 
			ResourceRequirement req = requirements.get(i);
			ret.append(padNum(numMaxSize, req.has()));
			if(i < requirements.size() - 1)
				ret.append(", ");
		}
		return ret +"]";
	}
	
	public String requiredResourcesAsString(int numMaxSize) {
		StringBuilder ret = new StringBuilder("[");
		for(int i = 0; i < requirements.size(); ++i) { 
			ResourceRequirement req = requirements.get(i);
			ret.append(padNum(numMaxSize, req.need));
			if(i < requirements.size() - 1)
				ret.append(", ");
		}
		return ret +"]";
	}
	
	public String neededResourcesAsString(int numMaxSize) {
		StringBuilder ret = new StringBuilder("[");
		for(int i = 0; i < requirements.size(); ++i) { 
			ResourceRequirement req = requirements.get(i);
			ret.append(padNum(numMaxSize, req.remainingNeed()));
			if(i < requirements.size() - 1)
				ret.append(", ");
		}
		return ret +"]";
	}

	public void show(String name) {
		System.out.printf("Customer %s: ", name);
		if (satisfied()) {
			System.out.print("Satisfied and has [");
			int i = 0;
			for (ResourceRequirement req : requirements) {
				System.out.printf("R%d:%d", i++, req.has);
				if (i < requirements.size())
					System.out.print(", ");
			}
		} else {
			System.out.print("needs [");
			int i = 0;
			for (ResourceRequirement req : requirements) {
				System.out.printf("R%d:%d", i++, req.need);
				if (i < requirements.size())
					System.out.print(", ");
			}
			System.out.print("] and has [");
			i = 0;
			for (ResourceRequirement req : requirements) {
				System.out.printf("R%d:%d", i++, req.has);
				if (i < requirements.size())
					System.out.print(", ");
			}
		}
		System.out.println("]");
	}

}
