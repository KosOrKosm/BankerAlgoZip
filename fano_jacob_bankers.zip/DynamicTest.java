package banking;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

public class DynamicTest {

	public static ReentrantLock bank_lock = new ReentrantLock();
	
	private static void sleep(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private static String spacerString(int spaces) {
		char[] raw = new char[spaces];
		Arrays.fill(raw, ' ');
		return new String(raw);
	}

	private static String centerString(int desiredLength, String base) {
		int spacerSize;
		if(desiredLength > base.length())
			spacerSize = (desiredLength - base.length()) / 2;
		else 
			spacerSize = 0;
		
		String spacer = spacerString(spacerSize);
		return spacer + base + spacer;
	}

	private static void printSystemState(Banker bank, List<Customer> customers) {

		// System-wide Openings
		System.out.print("Bank Status: ");
		bank.show();
		System.out.println();

		// Per Customer Stuff
		int arrNumSize = 2;
		int arraySize = bank.resourceCount() * (arrNumSize * 2 + 2) + 2;
		String header = centerString(arraySize, "ALLOCATED") + " " + centerString(arraySize, "MAXIMUM") + " " + centerString(arraySize, "NEED");
		System.out.println(centerString(4 * arraySize, header));

		for (Customer cst : customers) {
			if(cst.complete())
				continue;
			String cst_status = centerString(arraySize, cst.allocatedResourcesAsString(arrNumSize));
			cst_status += centerString(arraySize, cst.requiredResourcesAsString(arrNumSize));
			cst_status += centerString(arraySize, cst.neededResourcesAsString(arrNumSize));
			System.out.println(centerString(4 * arraySize, cst_status));
		}
		System.out.println();

	}

	private static void simulate(Banker bank, List<Customer> customers) {
		System.out.println(
				"\nBanker's algorithm simulation beginning...\n--------------------------------------------\n");
		printSystemState(bank, customers);
		System.out.println();

		List<Thread> runners = new ArrayList<>();

		// Create a runner for each customer to execute the Banker's Algorithm
		for (Customer cst : customers)
			runners.add(new Thread(() -> {
				
				synchronized (System.out) {
					System.out.println("<<< Customer thread p#" + Thread.currentThread().getId() + " started... >>>");
				}
				
				while (!cst.satisfied()) {

					// Only one customer can access the bank at a time
					bank_lock.lock();

					// Perform the primary checks of the Banker's algorithm
					if (cst.canFullyAllocate(bank)) {
						
						if (bank.isStateSafe(cst, customers)) {

							// Request approved! Take resources from the bank
							cst.allocateAllResources(bank);
							
							synchronized (System.out) {
								System.out.println(
										"\nCustomer p#" + Thread.currentThread().getId() + " request was granted");
								printSystemState(bank, customers);
							}
							
							// Simulate processing time by going to sleep
							bank_lock.unlock(); // don't hold bank while "processing"
							sleep(1000);
							bank_lock.lock(); 
							
							
							// Customer has now finished. Return resources to the bank.
							cst.returnAllResources(bank);

							synchronized (System.out) {
								System.out.println("\nCustomer p#" + Thread.currentThread().getId()
										+ " has released all resources and is shutting down");
								printSystemState(bank, customers);
								System.out.println();
							}

						} else synchronized (System.out) {
							System.out.println("\nCustomer p#" + Thread.currentThread().getId()
									+ " request was denied -- would cause unsafe state");
							cst.show(Long.toString(Thread.currentThread().getId()));
							printSystemState(bank, customers);
						}
					} else synchronized (System.out) {
						System.out.println("\nCustomer p#" + Thread.currentThread().getId()
								+ " request was denied -- insufficient resources");
						cst.show(Long.toString(Thread.currentThread().getId()));
						printSystemState(bank, customers);
					}

					// Release access to the bank
					bank_lock.unlock();

					// Don't check constantly; sleep for a bit so the processor isn't constantly busy.
					sleep(50);
					
				}
				
				synchronized (System.out) {
					System.out.println(">>>>>>>>>>>>>>> Customer thread p#" + Thread.currentThread().getId()
							+ " shutting down... <<<<<<<<<<<<<<<<<\\n\\n");
				}
				
			}));

		// Dispatch the threads and watch the magic
		for (Thread runner : runners)
			runner.start();

		// Join all the threads before quitting.
		// NOTE: Since it is possible for a join to get interrupted, 
		// we keep trying to join all threads until no threads are left
		while (!runners.isEmpty()) {
			for (int i = 0; i < runners.size();) {
				try {
					runners.get(i).join();

					// only remove after the join has successfully completed
					runners.remove(i);

				} catch (InterruptedException e) {
					e.printStackTrace();
					++i;
				}
			}
		}

		System.out.println("\nBanker's algorithm simulation completed...\n\n");
	}

	private static void processResourcePool(String line, List<Integer> res) {
		res.clear();
		String[] split = line.split(",");
		for (String str : split) {
			res.add(Integer.parseInt(str.trim()));
		}
	}

	private static void processFile(String file) {
		try {
			File rawData = new File(file);
			try (Scanner reader = new Scanner(rawData)) {
				if (!reader.hasNextLine())
					System.out.println("\tFile empty, aborting!\t");
				else {

					List<Integer> res = new ArrayList<>();
					List<Customer> customers = new ArrayList<>();

					// First line has bank resources
					String firstLine = reader.nextLine().trim();
					processResourcePool(firstLine, res);
					Banker bank = new Banker(res);

					while (reader.hasNextLine()) {
						String line = reader.nextLine().trim();
						if(line.isEmpty())
							continue;
						processResourcePool(line, res);
						if(res.size() != bank.resourceCount() * 2)
							throw new IllegalStateException(file+" is not a valid Banker's Algorithm scenario file!");
						List<Integer> has = res.subList(0, bank.resourceCount());
						List<Integer> need = res.subList(bank.resourceCount(), res.size());
						customers.add(new Customer(need, has));

					}

					simulate(bank, customers);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		if (args.length < 1)
			throw new IllegalArgumentException("Please provide at least one file to process!");

		for (String file : args) {
			processFile(file);
		}

		System.out.println("\t\t...done.\n");

	}

}
