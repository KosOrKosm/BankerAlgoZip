package banking;

import java.util.List;
import java.util.ArrayList;

public class Banker {

	private final List<Integer> bank = new ArrayList<>();

	public Banker(List<Integer> maxes) {
		bank.addAll(maxes);
	}

	public int resourceCount() {
		return bank.size();
	}

	public void allocateResource(int resource, int amount) {
		if(bank.get(resource) - amount < 0)
			throw new IllegalArgumentException("Attempted to allocate more resources than system has! System had "
				+ bank.get(resource) + " resources and was asked for " + amount);
		bank.set(resource, bank.get(resource) - amount);
	}

	public void deallocateResource(int resource, int amount) {
		bank.set(resource, bank.get(resource) + amount);
	}

	public boolean hasResources(List<Integer> pendingAlloc) {
		for (int i = 0; i < pendingAlloc.size(); ++i)
			if (bank.get(i) - pendingAlloc.get(i) < 0)
				return false;
		return true;
	}

	public boolean isStateSafe(List<Integer> pendingAlloc, List<Customer> dependents) {
		Customer[] arr = new Customer[dependents.size()];
		return isStateSafe(pendingAlloc, dependents.toArray(arr));
	}

	public boolean isStateSafe(List<Integer> pendingAlloc, Customer[] dependents) {

		boolean safe = true;

		// If the bank cannot fully allocate the main customer, no point checking the rest
		if (!hasResources(pendingAlloc))
			return false;

		// Enter the state that perform the desired allocation would create...
		for (int i = 0; i < pendingAlloc.size(); ++i)
			allocateResource(i, pendingAlloc.get(i));

		// Make sure there is some follow-up move available...
		for (Customer cst : dependents) {

			// Don't compare to self, complete tasks, or satisfied tasks
			if (cst.satisfied() || cst.complete())
				continue;

			// Only becomes unsafe once another customer is found for the first time
			safe = false;

			// If even a single other customer can be satisfied, the allocation is safe.
			if (hasResources(cst.needs())) {
				safe = true;
				break;
			}

		}

		// Restore the non-allocated state
		for (int i = 0; i < pendingAlloc.size(); ++i)
			deallocateResource(i, pendingAlloc.get(i));

		return safe;
	}
	
	public void printAvailable() {
		System.out.print("Available[");
		int i = 0;
		for (int avail : bank) {
			System.out.printf("R%d:%d", i++, avail);
			if (i < bank.size())
				System.out.print(", ");
		}
		System.out.print("]");
	}

	public void show() {
		System.out.print("Bank[");
		printAvailable();
		System.out.print("]");
		System.out.println();
	}

}
