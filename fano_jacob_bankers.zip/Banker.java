package banking;

import java.util.List;
import java.util.ArrayList;

public class Banker {

	private final List<Integer> bank = new ArrayList<>();

	public Banker(List<Integer> maxes) {
		bank.addAll(maxes);
	}

	public void allocateResource(int resource, int amount) {
		if (cannotCompleteRequest(resource, amount))
			throw new IllegalArgumentException("Attempted to allocate more resources than system has! System had "
					+ bank.get(resource) + " resources and was asked for " + amount);
		bank.set(resource, bank.get(resource) - amount);
	}

	public void deallocateResource(int resource, int amount) {
		bank.set(resource, bank.get(resource) + amount);
	}

	public boolean cannotCompleteRequest(int resource, int request) {
		return bank.get(resource) - request < 0;
	}

	public int resourceCount() {
		return bank.size();
	}

	public boolean isStateSafe(Customer toAlloc, List<Customer> dependents) {
		Customer[] arr = new Customer[dependents.size()];
		return isStateSafe(toAlloc, dependents.toArray(arr));
	}

	public boolean isStateSafe(Customer toAlloc, Customer[] dependents) {

		boolean safe = true;

		// If the bank cannot fully allocate the main customer, no point checking the
		// rest
		if (!toAlloc.canFullyAllocate(this))
			return false;

		// Enter the state that perform the desired allocation would create...
		List<Integer> pendingAlloc = toAlloc.needs();
		for (int i = 0; i < pendingAlloc.size(); ++i)
			allocateResource(i, pendingAlloc.get(i));

		// Make sure there is some follow-up move available...
		for (Customer cst : dependents) {

			// Don't compare to self, complete tasks, or satisfied tasks
			if (cst.equals(toAlloc) || cst.satisfied() || cst.complete())
				continue;

			// Only becomes unsafe once another customer is found for the first time
			safe = false;

			// If even a single other customer can be satisfied, the allocation is safe.
			if (cst.canFullyAllocate(this)) {
				safe = true;
				break;
			}

		}

		// Restore the non-allocated state
		for (int i = 0; i < pendingAlloc.size(); ++i)
			deallocateResource(i, pendingAlloc.get(i));

		return safe;
	}
	
	public void printAvailable() {
		System.out.print("Available[");
		int i = 0;
		for (int avail : bank) {
			System.out.printf("R%d:%d", i++, avail);
			if (i < bank.size())
				System.out.print(", ");
		}
		System.out.print("]");
	}

	public void show() {
		System.out.print("Bank[");
		printAvailable();
		System.out.print("]");
		System.out.println();
	}

}
